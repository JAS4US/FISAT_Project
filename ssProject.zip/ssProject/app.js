var express = require('express')
, http = require('http'), path = require('path');
var pg=require('pg')


 
var app = express();

const pool = new pg.Pool({
user: 'fisat',
host: 'fisatdb.fisat.edu',
database: 'fisatdb',
password: 'fisat',
port: '5432'
});


 
app.use(express.static(path.join(__dirname, 'public')));
/*JS client side files has to be placed under a folder by name 'public' */
app.use(express.bodyParser());
/*to access the posted data from client using request body*/
app.post('/post', function (req, res) {
    /* Handling the AngularJS post request*/
    
    //console.log("test : ",req);
    console.log("test22 : ",req.body.textdata);
    //console.log("test : ",req.body);
    
    
    res.setHeader('Content-Type', 'application/json');
    /*response has to be in the form of a JSON*/
    req.body.serverMessage = "NodeJS replying to angular"
        /*adding a new field to send it to the angular Client */
    res.end(JSON.stringify(req.body));
    
    //console.log("test2 : ",(JSON.stringify(req.body)));
    
    
    pool.connect((err, client, done) => {
          if (err) {
              //likely a connection error that will print to console.
              console.log("not connected");
              //done();
              //throw err;
          }
          else{
            console.log("connected");
            console.log("RRRRR : ",req);
            
            
            pool.query("insert into aaaa111 values('"+req.body.textdata+"')", (err, res) => {
            console.log(err, res);
            
            
            pool.end();
            });
          }
         });
    
    
    /*Sending the respone back to the angular Client */
});
 
http.createServer(app).listen(3000, function () {
    console.log("Express server listening on port 3000");
});
